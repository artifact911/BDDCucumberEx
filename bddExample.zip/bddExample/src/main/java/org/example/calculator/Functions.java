package org.example.calculator;

public class Functions {

    public int addition(int a, int b) {
        return a + b;
    }
}
